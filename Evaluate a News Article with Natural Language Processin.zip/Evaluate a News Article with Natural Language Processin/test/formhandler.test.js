import { handleSubmit } from 

describe('Testing the handleSubmit functionality', () => {
    test('handleSubmit should be defined', () => {
        expect(handleSubmit).toBeDefined()
    })
})